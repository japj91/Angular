import { NgModule } from '@angular/core';
import {ConversionComponent} from "./run/run";

@NgModule({
	declarations: [ConversionComponent],
	imports: [],
	exports: [ConversionComponent]
})
export class ComponentsModule {}
