/**
 * Created by japjohal on 2017-10-14.
 */
import { Component } from '@angular/core';

@Component({
    template: '<br>' +
    '<div> My About Page</div>'
})

export class about {

}